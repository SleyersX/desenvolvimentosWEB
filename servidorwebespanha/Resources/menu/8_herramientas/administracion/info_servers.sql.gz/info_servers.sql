-- MySQL dump 10.13  Distrib 5.5.35, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: soporteremotoweb
-- ------------------------------------------------------
-- Server version	5.5.35-0+wheezy1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `info_servers`
--

DROP TABLE IF EXISTS `info_servers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `info_servers` (
  `ip_server` varchar(20) NOT NULL,
  `name_server` varchar(20) DEFAULT NULL,
  `pais` varchar(3) DEFAULT NULL,
  `ldap_host` varchar(20) DEFAULT NULL,
  `DOMINIO` varchar(10) DEFAULT NULL,
  `base_dn` varchar(20) DEFAULT NULL,
  `ftp_concentrador` varchar(20) DEFAULT NULL,
  `ftp_user_name` varchar(30) DEFAULT NULL,
  `ftp_user_pass` varchar(30) DEFAULT NULL,
  `Idioma` varchar(3) DEFAULT NULL,
  PRIMARY KEY (`ip_server`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `info_servers`
--

LOCK TABLES `info_servers` WRITE;
/*!40000 ALTER TABLE `info_servers` DISABLE KEYS */;
INSERT INTO `info_servers` VALUES ('10.105.186.135','Soporte Brasil','BRA','10.105.186.5','DIAMTZ','DC=diamtz,DC=BR','BRCONCEN1','userinfoft','hosthost','ESP'),('10.132.221.18','Soporte China','CHI','10.132.190.23','LARCN','DC=larcn,DC=dsd','CZCONCEN1','lares/usertpvsop','al59e1q6','ENG'),('10.208.162.17','Soporte Espana 2','ESP','10.208.146.1','LARES','DC=lares,DC=dsd','ESCONCEN1','lares/usertpvsop','al59e1q6','ESP'),('10.208.162.6','Soporte Espana 1','ESP','10.208.146.1','LARES','DC=lares,DC=dsd','ESCONCEN1','lares/usertpvsop','al59e1q6','ESP'),('10.246.64.73','Soporte Portugal','POR','10.246.64.104','LARPT','DC=larpt,DC=dsd','PTCONCEN1','lares/usertpvsop','al59e1q6','ESP'),('10.94.202.121','Soporte Argentina','ARG','10.71.216.216','LADIA','DC=LA,DC=DIA','ARCONCEN1','lares/usertpvsop','al59e1q6','ESP'),('10.95.81.137','Soporte Paraguay','PAR','10.71.216.216','LADIA','DC=LA,DC=DIA','PYCONCEN1','','','ESP');
/*!40000 ALTER TABLE `info_servers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2016-12-13 15:55:30
