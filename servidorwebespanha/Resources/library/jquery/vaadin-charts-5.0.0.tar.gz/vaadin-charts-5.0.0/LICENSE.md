# Vaadin Charts Licensing

**_Vaadin Charts_ is a charting tool for [Vaadin](http://vaadin.com)**

_Vaadin Charts_ is distributed under the terms of
[Commercial Vaadin Add-On License version 3.0](https://vaadin.com/license/cval-3) ("CVALv3"). A copy of the license is included as ```LICENSE.txt``` in this software package.

You must either accept the terms of the above mentioned license agreement or delete the Software immediately.

If you have any questions on licensing terms, please contact us through
[the vaadin.com web-site](http://vaadin.com/contact).
