import './sweetalert2.scss'
import sweetAlert from './sweetalert2'

export default sweetAlert
