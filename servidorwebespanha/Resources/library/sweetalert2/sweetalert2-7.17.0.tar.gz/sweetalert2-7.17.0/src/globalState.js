import defaultParams from './utils/params.js'

export default {
  popupParams: Object.assign({}, defaultParams)
}
